import React from 'react'
import Signup from './Signup'

const page = () => {
  return (
    <div>
        <Signup/>
    </div>
  )
}

export default page