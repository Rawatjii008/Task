import React from 'react'
import Admin from '../new-admin-dashboard/Admin'


const page = () => {
  return (
    <div>
      <Admin/>
    </div>
  )
}

export default page
