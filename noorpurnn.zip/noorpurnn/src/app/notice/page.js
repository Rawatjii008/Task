import React from 'react'
import Notice from './Notice'

const page = () => {
  return (
    <div>
        <Notice />
    </div>
  )
}

export default page