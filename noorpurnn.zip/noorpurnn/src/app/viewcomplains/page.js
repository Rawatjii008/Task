"use client";
import Viewcomplains from "./Viewcomplains";

const page = () => {
  return (
    <div>
      <Viewcomplains />
    </div>
  );
};

export default page;
