import React from 'react'
import ContactForm from './Contactus'

const page = () => {
  return (
    <div>
        <ContactForm/>
    </div>
  )
}

export default page