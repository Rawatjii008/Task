import React from 'react'

const GarbageCollector = () => {
  return (
    <div>
      hi garbage collecter
    </div>
  )
}

export default GarbageCollector;
  