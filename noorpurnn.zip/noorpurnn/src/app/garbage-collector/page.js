import React from 'react'
import GarbageCollector from './GarbageCollector'

const page = () => {
  return (
    <div>
      <GarbageCollector/>
    </div>
  )
}

export default page
