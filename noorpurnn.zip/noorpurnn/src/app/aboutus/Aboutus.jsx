"use client";
import CommitteeBoard from '@/components/CommitteeBoard'
import Municipal_Works_Department from '@/components/Municipal_Works_Department';
import Nagar_Palika_Vibhag from '@/components/Nagar_Palika_Vibhag'
import Sectionpeople from '@/components/Sectionpeople'
import Tabs from '@/components/Tabs'
import Contact_formula from '@/components/contact_formula'
import React from 'react'

const About = () => {
  return (
    <div className='p-5'>
      <Tabs/>
      {/* <Sectionpeople/> */}
      {/* <Contact_formula /> */}
      {/* <CommitteeBoard />
      <Nagar_Palika_Vibhag/>
      <Municipal_Works_Department /> */}
    </div>
  )
}

export default About
