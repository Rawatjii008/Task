import React from "react";
import About from "./Aboutus";

const page = () => {
  return (
    <div>
      <About />
    </div>
  );
};

export default page;
