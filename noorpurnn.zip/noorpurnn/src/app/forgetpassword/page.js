import React from 'react'
import ForgetPass from './ForgetPass'

const page = () => {
  return (
    <div>
      <ForgetPass/>
    </div>
  )
}

export default page
