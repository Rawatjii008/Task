import React from 'react'
import Tender from './Tender'

const page = () => {
  return (
    <div><Tender/></div>
  )
}

export default page