import React from 'react'
import Admin from './Admin'

const page = () => {
  return (
    <div>
      <Admin/>
    </div>
  )
}

export default page
