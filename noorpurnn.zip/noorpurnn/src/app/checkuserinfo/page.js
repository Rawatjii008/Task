import React from 'react'
import CheckUserInfo from './CheckUserInfo'

const Page = () => {
  return (
    <div>
        <CheckUserInfo/>
    </div>
  )
}

export default Page