import React from 'react'
import OnlineServices from './Services'

const page = () => {
  return (
    <div>
      <OnlineServices/>
    </div>
  )
}

export default page
