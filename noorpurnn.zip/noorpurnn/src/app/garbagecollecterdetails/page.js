import React from 'react'
import GarbageCollectordetails from './garbagecollectordetails'

const page = () => {
  return (
    <div>
      <GarbageCollectordetails/>
    </div>
  )
}

export default page
