import React from 'react'
import Departments from './Departments'

const page = () => {
  return (
    <div>
      <Departments/>
    </div>
  )
}

export default page
