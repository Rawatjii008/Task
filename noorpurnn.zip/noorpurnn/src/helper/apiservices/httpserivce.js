// export const httpService = "https://13.126.160.22:3000/api";
export const httpService = "http://localhost:3000/api";
// export const httpService = "https://noorpurnn.vercel.app/api";
// export const httpService = "https://nigamnurpur.duckdns.org/api";


